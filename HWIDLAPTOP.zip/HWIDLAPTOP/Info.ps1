Set-ExecutionPolicy -Scope Process -ExecutionPolicy Unrestricted
Set-Location D:\\HWIDLAPTOP
.\Get-WindowsAutoPilotInfo.ps1 -OutputFile D:\HWIDLAPTOP\AutoPilotHWID.csv