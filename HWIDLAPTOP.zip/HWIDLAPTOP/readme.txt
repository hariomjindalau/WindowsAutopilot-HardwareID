Windows Autopilot Hardware Information Extract from Windows 10 Laptop/Desktop by tech24online.com:
===================================================================================================

Capture Hardware Hash from Windows 10 OS.
	Copy HWIDLAPTOP folder into USB
	Mount USB into Windows 10 Laptop/Desktop.
	At Boot Screen press Shift + F10
	Go to E:\
	Cd HWIDLAPTOP
	type info.bat
	This will open the powershell and collect the information.
	once completed, you can exit the command prompt.
	remove the usb drive.
	file AutopilotHWID.csv is ready.